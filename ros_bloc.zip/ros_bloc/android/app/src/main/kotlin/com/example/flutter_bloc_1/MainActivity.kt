package com.example.flutter_bloc_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
