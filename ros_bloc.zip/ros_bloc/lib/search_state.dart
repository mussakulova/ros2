part of 'search_bloc.dart';

class SearchState {
  final List users;

  SearchState({
    this.users = const [],
  });
}
